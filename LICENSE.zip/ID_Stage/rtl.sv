module id_stage (
    input  logic        clk,
    input  logic        reset,
    input  logic        stall,
    input  logic [31:0] instruction,
    input  logic [31:0] wb_data,
    output logic [31:0] rs1_data,
    output logic [31:0] rs2_data,
    output logic [31:0] imm_out,
    output logic [6:0]  opcode_out_d,
    output logic [6:0]  imm11_5,
    output logic [2:0]  fn3_out_d,
    output logic        fn7_5,
    output logic [2:0]  aluop,
    output logic [1:0]  memtoreg,
    output logic        branch,
    output logic        mem_write,
    output logic        mem_read,
    output logic        alu_src,
    output logic        mux_inp
);

    logic [4:0] rs1_sel;
    logic [4:0] rs2_sel;
    logic [4:0] rd_sel;
    logic [11:0] imm_i_s_b;
    logic [19:0] imm_u_j;
    logic reg_write_control;
    logic reg_write_enabled;
    logic memwrite_internal;
    logic memread_internal;
    logic alusrc_internal;

    decoder u_decoder (
        .instruction(instruction),
        .rs1(rs1_sel),
        .rs2(rs2_sel),
        .rd(rd_sel),
        .opcode(opcode_out_d),
        .imm11_5(imm11_5),
        .fn3(fn3_out_d),
        .imm(imm_i_s_b),
        .imm_uj(imm_u_j),
        .fn7_5(fn7_5)
    );

    imm_generator u_imm_generator (
        .imm_input(imm_i_s_b),
        .fn3(fn3_out_d),
        .opcode(opcode_out_d),
        .imm_input_uj(imm_u_j),
        .imm_output(imm_out)
    );

    main_control u_main_control (
        .opcode(opcode_out_d),
        .fn3(fn3_out_d),
        .memtoreg(memtoreg),
        .branch(branch),
        .mux_inp(mux_inp),
        .memread(memread_internal),
        .memwrite(memwrite_internal),
        .alusrc(alusrc_internal),
        .reg_write(reg_write_control),
        .aluop(aluop)
    );

    assign reg_write_enabled = reg_write_control && !stall;
    assign mem_read = memread_internal;
    assign mem_write = memwrite_internal;
    assign alu_src = alusrc_internal;

    register_file u_register_file (
        .rs1_sel(rs1_sel),
        .rs2_sel(rs2_sel),
        .reg_write(reg_write_enabled),
        .clk(clk),
        .reset(reset),
        .wb_data(wb_data),
        .rd_sel(rd_sel),
        .rs1_data(rs1_data),
        .rs2_data(rs2_data)
    );

endmodule
